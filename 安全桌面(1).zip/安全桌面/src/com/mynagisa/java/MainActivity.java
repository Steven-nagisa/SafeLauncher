package com.mynagisa.java;

import android.app.*;
import android.app.admin.*;
import android.content.*;
import android.content.pm.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import java.io.*;

import java.lang.Process;


public class MainActivity extends Activity
{
	@Override
	protected void onResume() {
		Intent intent1 = new Intent(MainActivity.this, service.class);
		startService(intent1);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); 
		/**
		 * SCREEN_ORIENTATION_SCREEN_ORIENTATION_landscape
		 */
		if(getRequestedOrientation()!=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		super.onResume();
	}

	private DevicePolicyManager dpm;// 
	private ComponentName componentName;
	private boolean isAdminActive;
	Runtime runtime = Runtime.getRuntime();

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
	}
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Intent intent1 = new Intent(MainActivity.this, service.class);
		startService(intent1);
		dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
		SharedPreferences isFirstRun = getSharedPreferences("first",MODE_PRIVATE);
		boolean isFirst = isFirstRun.getBoolean("isfirstRun",true);
		if (isFirst){
			TipsUtils.toast(getApplicationContext(),"isFirstRun");
			final EditText edit = new EditText(this);
			edit.setMaxLines(1);
			edit.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
			edit.setGravity(Gravity.CENTER);
			new AlertDialog.Builder(this)
				.setTitle("自定义密码")
				.setIcon(R.drawable.ic_launcher)
				.setMessage("请输入您的自定义密码：")
				.setView(edit)
				.setPositiveButton("确认",new DialogInterface.OnClickListener(){
					public void onClick(DialogInterface dialog, int which) {
						if (edit.getText().length() < 4){
							Dialog("请重新输入密码","Android仅支持4位及以上的数字字母密码策略"+"\n请修改您的密码");

						}else{
							Dialog1("请牢记您的自定义密码！！丢失不可恢复！！","您的自定义密码为："+edit.getText().toString()+"\n请牢记您的密码！！！丢失不可恢复！！！");
							SharedPreferences.Editor newpwd = getSharedPreferences("pwd",MODE_PRIVATE).edit();
							newpwd.putString("pwd",edit.getText().toString());
							newpwd.putInt("versionCode",getVersionCode(MainActivity.this));
							newpwd.commit();
							SharedPreferences.Editor editor = getSharedPreferences("first",MODE_PRIVATE).edit();
							editor.putBoolean("isfirstRun",false);
							editor.commit();
							getVersionCode(MainActivity.this);
						}
					}
				})
				.setNegativeButton("使用默认密码",new DialogInterface.OnClickListener(){
					public void onClick(DialogInterface dialog, int which) {
						Dialog1("请牢记此默认密码密码！！丢失不可恢复！！","默认密码为： "+"myusd.net"+"\n请牢记默认密码！！！丢失不可恢复！！！");
						SharedPreferences.Editor newpwd = getSharedPreferences("pwd",MODE_PRIVATE).edit();
						newpwd.putString("pwd","myusd.net");
						newpwd.putInt("versionCode",getVersionCode(MainActivity.this));
						newpwd.commit();
						SharedPreferences.Editor editor = getSharedPreferences("first",MODE_PRIVATE).edit();
						editor.putBoolean("isfirstRun",false);
						editor.commit();
						getVersionCode(MainActivity.this);
					}
				})
				.setNeutralButton("使用帮助",new DialogInterface.OnClickListener(){
					public void onClick(DialogInterface dialog, int which) {
						Intent intent= new Intent();         
						intent.setAction("android.intent.action.VIEW");     
						Uri content_url = Uri.parse("http://pzhsz.ltd/readme.html");    
						intent.setData(content_url);   
						startActivity(intent); 
						finish();
					}
				})
				.show();
		}
		checkAdmin();
		if (!isAdminActive) {
			showNormalDialog();
			getAdmin(componentName);
			TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
			Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
		}else{
			TipsUtils.notify(getApplicationContext(), "点击可返回 安全桌面");
		}

		findViewById(R.id.Button1).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					checkAdmin();
					if (!isAdminActive) {
						showNormalDialog();
						getAdmin(componentName);
						TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
						Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
					}else{
						boolean is_installed = isInstalled.isAvilible(MainActivity.this,"com.mynagisa.lock");
						if(is_installed){
							TipsUtils.notify(getApplicationContext(), "锁屏成功！");
							TipsUtils.toast(getApplicationContext(),"锁屏成功！");
							Intent intent_r1 = getPackageManager().getLaunchIntentForPackage("com.mynagisa.lock");
							startActivity(intent_r1);
							finish();
						}else{
							//Uri uri = Uri.parse("market://details?id=com.tencent.mm");
							Uri uri = Uri.parse("http://www.coolapk.com/apk/com.mynagisa.lock");
							TipsUtils.notify(getApplicationContext(),"请先安装 一键锁屏 ");
							TipsUtils.toast(getApplicationContext(),"请先安装 一键锁屏 ");
							Intent it = new Intent(Intent.ACTION_VIEW, uri); 
							startActivity(it); 
						}
					}
				}
			});
		
		findViewById(R.id.Button_1).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					//Autoinstall.setUrl(Environment.getExternalStorageDirectory()
					//				   + "/Download/appslist.apk");
					//Autoinstall.install(MainActivity.this);
					checkAdmin();
					if (!isAdminActive) {
						showNormalDialog();
						getAdmin(componentName);
						TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
						Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
					}else{
						TipsUtils.notify(getApplicationContext(), "正在进入 安全桌面...");
						Toast.makeText(MainActivity.this,"正在进入 安全桌面...",Toast.LENGTH_SHORT).show();
						Intent intent = new Intent(MainActivity.this, Launcher.class);
						startActivity(intent);
						Intent intent1 = new Intent(MainActivity.this, service.class);
						startService(intent1);
						
						overridePendingTransition(R.anim.in_from_right, R.anim.out_to_left);
						
				}

		}
			});
			
		findViewById(R.id.Button_1).setOnLongClickListener(new OnLongClickListener() {

				@Override
				public boolean onLongClick(View p1)
				{
					checkAdmin();
					if (!isAdminActive) {
						showNormalDialog();
						getAdmin(componentName);
						TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
						Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
					}else{
						Toast.makeText(MainActivity.this,"软件更新 http://pzhsz.ltd/apk/javalauncher.apk",Toast.LENGTH_LONG).show();
						TipsUtils.notify(getApplicationContext(), "软件更新 http://pzhsz.ltd/apk/javalauncher.apk");
					}
					return false;
				}
			});
			
		findViewById(R.id.Button_2).setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View p1)
				{
					checkAdmin();
					if (!isAdminActive) {
						showNormalDialog();
						getAdmin(componentName);
						TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
						Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
					}else{
						TipsUtils.notify(getApplicationContext(), "正在进入 设置...");
						Toast.makeText(MainActivity.this,"正在进入 设置...",Toast.LENGTH_SHORT).show();
						Intent r2_Intent = getPackageManager().getLaunchIntentForPackage("com.android.settings");    
						startActivity(r2_Intent);
						overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}

				}
			});
		findViewById(R.id.Button_2).setOnLongClickListener(new OnLongClickListener() {

				@Override
				public boolean onLongClick(View p1)
				{
					checkAdmin();
					if (!isAdminActive) {
						showNormalDialog();
						getAdmin(componentName);
						TipsUtils.notify(getApplicationContext(), "请先激活设备管理器");
						Toast.makeText(MainActivity.this,"请先激活设备管理器",Toast.LENGTH_LONG).show();
					}else{
						TipsUtils.notify(getApplicationContext(), "正在取消设备管理器");
						Toast.makeText(MainActivity.this,"正在取消激活设备管理器",Toast.LENGTH_SHORT).show();
						resetpwd();
					}
					return false;
				}
			});
			}
			
	
	public void locklong() {
		int i =0;
		while(i<500){
			this.dpm.lockNow();
			long sleep_t=50;
			try {
				Thread.sleep(sleep_t);
				++i;
			}
			catch(InterruptedException interruptedException0){
				interruptedException0.printStackTrace();
			}
		}
	}
	
		
	public static int getVersionCode(Context context){
		int vCode = 0;
		try {
			vCode = context.getPackageManager().getPackageInfo(context.getPackageName(),0).versionCode;
			TipsUtils.notify(context,"当前版本号："+vCode);
		}catch (PackageManager.NameNotFoundException e){
			e.printStackTrace();
		}
		return vCode;
	}
	
	private void showNormalDialog(){
        /* @setIcon 设置对话框图标
         * @setTitle 设置对话框标题
         * @setMessage 设置对话框消息提示
         * setXXX方法返回Dialog对象，因此可以链式设置属性
         */
        final AlertDialog.Builder normalDialog = 
            new AlertDialog.Builder(MainActivity.this);
        normalDialog.setIcon(R.drawable.ic_launcher);
        normalDialog.setTitle("使用须知：");
        normalDialog.setMessage("安全桌面 需要以下应用配套使用，如不安装以下应用将使安全桌面不能使用或者崩溃！ \n"+"请将安全桌面设置为默认桌面！ \n"+"(1.5版本需要以下应用：未来课堂、WPS Office、华为相机、华为文件管理、录音机、金山词霸、计算器、图库、ES文件浏览器、备忘录、一个木函、Google Chrome、华为应用商店)");
        normalDialog.setPositiveButton("我已安装", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent();
					intent.setAction("android.intent.action.MAIN");
					intent.addCategory("android.intent.category.HOME");
					MainActivity.this.startActivity(intent);
				}
			});
        normalDialog.setNegativeButton("前去安装", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					
					Intent intent = new Intent();    
					//Intent intent = new Intent(Intent.ACTION_VIEW,uri);    
					intent.setAction("android.intent.action.VIEW");    
					Uri content_url = Uri.parse("http://pzhsz.ltd/apk/javalauncher");   
					intent.setData(content_url);
					startActivity(intent);
				}
			});
        // 显示
        normalDialog.show();
    }
	public static boolean ping() {
        try {
            //服务器ip地址
            String ip = "60.205.45.74";
            Process p = Runtime.getRuntime().exec("ping -c 1 -w 100 " + ip);
            InputStream input = p.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(input));
            StringBuffer stringBuffer = new StringBuffer();
            String content;
            while ((content = in.readLine()) != null) {
                stringBuffer.append(content);
            }
            int status = p.waitFor();
            if (status == 0) {
                return true;
            }
        }
        catch (IOException e) {}
        catch (InterruptedException e) {}
        return false;
    }
	private void lock() {
		dpm.lockNow();
	}

	private void resetpwd() {
		String password = getSharedPreferences("pwd",
			Context.MODE_PRIVATE).getString("pwd", "myusd.net");
		dpm.resetPassword(password, 0); 
		locklong();
	}
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		switch(keyCode){
			case 3:
				Toast.makeText(MainActivity.this,"mynagisa.com",Toast.LENGTH_SHORT).show();
				break;
			case 4:
				Toast.makeText(MainActivity.this,"mynagisa.com",Toast.LENGTH_SHORT).show();
				break;
			case 82:
				Toast.makeText(MainActivity.this,"mynagisa.com",Toast.LENGTH_SHORT).show();
				break;
		}
		return true;
	}

	private void Dialog(String title,String text){
        /* @setIcon 设置对话框图标
         * @setTitle 设置对话框标题
         * @setMessage 设置对话框消息提示
         * setXXX方法返回Dialog对象，因此可以链式设置属性
         */
        final AlertDialog.Builder normalDialog = 
            new AlertDialog.Builder(MainActivity.this);
        normalDialog.setIcon(R.drawable.ic_launcher);
        normalDialog.setTitle(title);
        normalDialog.setMessage(text);
        normalDialog.setPositiveButton("确定", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent reintent = getIntent();
					finish();
					startActivity(reintent);
				}
			});
        normalDialog.setNegativeButton("退出", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			});
        // 显示
        normalDialog.show();
    }

	private void Dialog1(String title,String text){
        final AlertDialog.Builder normalDialog = 
            new AlertDialog.Builder(MainActivity.this);
        normalDialog.setIcon(R.drawable.ic_launcher);
        normalDialog.setTitle(title);
        normalDialog.setMessage(text);
        normalDialog.setPositiveButton("确定", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					getAdmin(componentName);
				}
			});
        normalDialog.setNegativeButton("退出", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			});
        // 显示
        normalDialog.show();
    }

	private void checkAdmin(){
		componentName = new ComponentName(MainActivity.this,MyAdmin.class);
		isAdminActive = dpm.isAdminActive(componentName);
	}
	private void getAdmin(ComponentName componentName) {

		Intent intent = new Intent();

		intent.setAction(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);

		intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, componentName);

		intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,"此应用需要激活设备管理器才能正常使用");

		startActivity(intent);
	}
	public void changepwd(String pwd){
		dpm.resetPassword(pwd,0);
		this.dpm.lockNow();
	}
}
