package com.mynagisa.java;

import android.app.*;
import android.app.admin.*;
import android.content.*;
import android.content.pm.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import java.lang.reflect.*;
import android.widget.*;
import android.net.*;

public class Launcher extends Activity{
	@Override
	protected void onResume() {
		Intent intent1 = new Intent(Launcher.this, service.class);
		startService(intent1);
		
		if(getRequestedOrientation()!=ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE){
			setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		}
		super.onResume();
	}
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.launcher);
		
		findViewById(R.id.launcherButton_wlkt).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					boolean is_installed_1 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_1){
					TipsUtils.notify(getApplicationContext(), "正在进入 未来课堂...");
					Toast.makeText(Launcher.this,"正在进入 未来课堂...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.dfwd.wlkt");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("未来课堂","http://wlkt.eastedu.com");
					}
				}
			});
		findViewById(R.id.launcherButton_wlkt).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					boolean is_installed_2 = isInstalled.isAvilible(Launcher.this,"com.kingsoft");
					if(is_installed_2){
					TipsUtils.notify(getApplicationContext(), "正在进入 金山词霸...");
					Toast.makeText(Launcher.this,"正在进入 金山词霸...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.kingsoft");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("金山词霸","market://details?id=com.kingsoft");
					}
					return false;
				}
			});
		findViewById(R.id.launcherButton_wps).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					boolean is_installed_3 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_3){
					TipsUtils.notify(getApplicationContext(), "正在进入 WPS Office...");
					Toast.makeText(Launcher.this,"正在进入 WPS Office...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("cn.wps.moffice_eng");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("WPS Office","market://details?id=cn.wps.moffice_eng");
					}
				}
			});
		findViewById(R.id.launcherButton_wps).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 计算器...");
					Toast.makeText(Launcher.this,"正在进入 计算器...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.android.calculator2");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					return false;
				}
			});
		findViewById(R.id.launcherButton_camera).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 相机...");
					Toast.makeText(Launcher.this,"正在进入 相机...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.huawei.camera");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
				}
			});
		findViewById(R.id.launcherButton_camera).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 图库...");
					Toast.makeText(Launcher.this,"正在进入 图库...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.android.gallery3d");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					return false;
				}
			});
		findViewById(R.id.launcherButton_files).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 文件管理...");
					Toast.makeText(Launcher.this,"正在进入 文件管理...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.huawei.hidisk");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
				}
			});
		findViewById(R.id.launcherButton_files).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					boolean is_installed_4 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_4){
					TipsUtils.notify(getApplicationContext(), "正在进入 ES文件浏览器...");
					Toast.makeText(Launcher.this,"正在进入 ES文件浏览器...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.estrongs.android.pop");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("ES文件浏览器","market://details?id=com.estrongs.android.pop");
					}
					return false;
				}
			});
		findViewById(R.id.launcherButton_recorder).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 录音机...");
					Toast.makeText(Launcher.this,"正在进入 录音机...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.android.soundrecorder");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
				}
			});
		findViewById(R.id.launcherButton_recorder).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 备忘录...");
					Toast.makeText(Launcher.this,"正在进入 备忘录...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.example.android.notepad");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					return false;
				}
			});
		findViewById(R.id.launcherButton_mdm).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					boolean is_installed_5 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_5){
					TipsUtils.notify(getApplicationContext(), "正在进入 自助管理...");
					Toast.makeText(Launcher.this,"正在进入 自助管理...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.One.WoodenLetter");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("一个木函","http://www.coolapk.com/apk/com.One.WoodenLetter");
					}
				}
			});
			
		findViewById(R.id.launcherButton_browser).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					boolean is_installed_6 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_6){
					TipsUtils.notify(getApplicationContext(), "正在进入 浏览器...");
					Toast.makeText(Launcher.this,"正在进入 浏览器...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.android.chrome");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("Chrome","market://details?id=com.android.chrome");
					}
				}
			});
		findViewById(R.id.launcherButton_browser).setOnLongClickListener(new OnLongClickListener() {
				@Override
				public boolean onLongClick(View p1)
				{
					TipsUtils.notify(getApplicationContext(), "正在进入 电子邮件...");
					Toast.makeText(Launcher.this,"正在进入 电子邮件...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.android.email");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					return false;
				}
			});
		findViewById(R.id.launcherButton_apps).setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View p1)
				{
					boolean is_installed_7 = isInstalled.isAvilible(Launcher.this,"com.dfwd.wlkt");
					if(is_installed_7){
					TipsUtils.notify(getApplicationContext(), "正在进入 应用商店...");
					Toast.makeText(Launcher.this,"正在进入 应用商店...",Toast.LENGTH_SHORT).show();
					Intent r1_Intent = getPackageManager().getLaunchIntentForPackage("com.huawei.appmarket");    
					startActivity(r1_Intent);
					overridePendingTransition(R.anim.in_from_bottom, R.anim.out_to_top);
					}else{
						InstalledDialog("华为应用商店","market://details?id=com.huawei.appmarket");
					}
				}
			});
		
		}
		
	private void InstalledDialog(String app_name,final String url){
        final AlertDialog.Builder normalDialog = 
            new AlertDialog.Builder(Launcher.this);
        normalDialog.setIcon(R.drawable.ic_launcher);
        normalDialog.setTitle("注意:");
        normalDialog.setMessage("您未安装 "+app_name+"\n是否前去安装？");
        normalDialog.setPositiveButton("是的", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Uri uri = Uri.parse(url);
					Intent it = new Intent(Intent.ACTION_VIEW, uri); 
					startActivity(it); 
				}
			});
        normalDialog.setNegativeButton("取消", 
            new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					Intent intent = new Intent(Launcher.this, MainActivity.class);
					startActivity(intent);
					finish();
					overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
				}
			});
        // 显示
        normalDialog.show();
    }
		
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			Toast.makeText(Launcher.this,"You clicked the Back Key",Toast.LENGTH_SHORT).show();
			Intent intent = new Intent(Launcher.this, MainActivity.class);
			startActivity(intent);
			finish();
			overridePendingTransition(R.anim.in_from_left, R.anim.out_to_right);
		}else{
			Intent intent = new Intent();
			intent.setAction("android.intent.action.MAIN");
			intent.addCategory("android.intent.category.HOME");
			Launcher.this.startActivity(intent);
		}
		return true;
	}
	
	
}

