package com.mynagisa.java;

import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import java.util.*;
import com.mynagisa.java.*;

public class service extends Service
{
	Context context;
	@Override
	public IBinder onBind(Intent p1)
	{
		// TODO: Implement this method
		return null;
	}

	@Override
	public void onCreate()
	{
		context = this;
		Intent main = new Intent(this, MainActivity.class);
		this.startActivity(main);
		final Handler h = new Handler(new Handler.Callback(){
				public boolean handleMessage(Message msg)
				{
					ActivityManager am=(ActivityManager)context.getSystemService(context.ACTIVITY_SERVICE);
					List<ActivityManager.RunningTaskInfo> runningTasks = am.getRunningTasks(1); 
					ActivityManager.RunningTaskInfo runningTaskInfo = runningTasks.get(0); 
					ComponentName topActivity =runningTaskInfo.topActivity; 
					String packageName =topActivity.getPackageName(); 

					if(packageName.equals("com.mynagisa.java")){//判断是否是本应用
					}
					else{
						//不是本应用，启动应用，并kill掉之前的应用
						Intent intent=new Intent();
						intent.setClass(context,MainActivity.class);
						intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity(intent);
						am.killBackgroundProcesses(packageName);
					}
					return false;
				}
			});
		Timer timer;
		TimerTask timertask;
		timer = new Timer();
		timertask = new TimerTask(){
			@Override
			public void run()
			{
				h.obtainMessage().sendToTarget();

			}
		};

		timer.schedule(timertask,0,10);//0.1秒启动一次timertask,无延迟


	}
	@Override
	public void onStart(Intent intent, int startId)
	{
		Intent main = new Intent(this, MainActivity.class);
		this.startActivity(main);
		super.onStart(intent, startId);
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		flags = START_STICKY;
		return super.onStartCommand(intent, flags, startId);
	}
	
	@Override
	public void onDestroy()
	{
		// TODO: Implement this method
		Intent service = new Intent(this, service.class);
		this.startService(service);
		super.onDestroy();
	}
}
