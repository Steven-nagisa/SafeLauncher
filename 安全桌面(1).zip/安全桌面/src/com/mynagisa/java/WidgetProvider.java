package com.mynagisa.java;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.*;
import android.app.*;


public class WidgetProvider extends AppWidgetProvider{
	//每接收一次广播消息就调用一次，使用频繁
	public void onReceive(Context context, Intent intent) {
		
		super.onReceive(context, intent);
	}
	//每次更新都调用一次该方法，使用频繁
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
						 int[] appWidgetIds) {
		final int N = appWidgetIds.length;
        for (int i=0; i<N; i++) {
            int appWidgetId = appWidgetIds[i];
			Intent intent = new Intent();
			intent.setAction("android.intent.action.MAIN");
			intent.addCategory("android.intent.category.HOME");
            PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, 0);
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_layout);
            views.setOnClickPendingIntent(R.id.widget_button, pendingIntent);
            appWidgetManager.updateAppWidget(appWidgetId, views);
		super.onUpdate(context, appWidgetManager, appWidgetIds);
		}
	}
	//当该Widget第一次添加到桌面是调用该方法，可添加多次但只第一次调用
	public void onEnabled(Context context) {
		tips(context,"选择安全桌面保护您的设备⊙∀⊙！");
		super.onEnabled(context);
	}
	//当最后一个该Widget删除是调用该方法，注意是最后一个
	public void onDisabled(Context context) {
		tips(context,"已删除");
		tips(context,"欢迎提供反馈！");
		super.onDisabled(context);
	}
	
	public void tips(Context context, String text) {
		TipsUtils.toast(context, text);
		TipsUtils.notify(context, text);
	}
}
