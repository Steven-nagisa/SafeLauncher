package com.mynagisa.java;

import android.app.*;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.*;
import android.support.v4.app.*;
import android.support.v4.app.NotificationCompat.*;
import android.widget.*;

public class TipsUtils {

	private static int id = 1;
	private static NotificationManager notificationManager;
	private static Builder compat;

	public static void toast(Context context, String text) {
		toast(context, text, Toast.LENGTH_SHORT);
	}

	public static void toast(Context context, String text, int duration) {
		Toast.makeText(context, text, duration).show();
	}

	public static void notify(Context context, String text) {
		if (notificationManager == null) {
			notificationManager = (NotificationManager) context
					.getSystemService(Context.NOTIFICATION_SERVICE);
			compat = new NotificationCompat.Builder(context);
		}
		
		notificationManager.cancelAll();
		
		Intent intent = new Intent(context, MainActivity.class);
		PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        compat.setContentIntent(pendingIntent);
		compat.setContentTitle(text);
		compat.setSmallIcon(R.drawable.setting);
		compat.setTicker(text);
		compat.setContentText("点击可返回安全桌面");
		compat.setSubText("安全桌面正在运行");
		
		Notification notification = compat.build();
		notification.flags = Notification.FLAG_NO_CLEAR;
		notification.flags = Notification.FLAG_ONGOING_EVENT;
		notificationManager.notify(id, notification);
	}
}
